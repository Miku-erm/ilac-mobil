export const QUIZ = [
  {
    id: "q1",
    question: "Antibiyotikler hangi tür enfeksiyonlarda etkilidir?",
    options: ["Viral", "Bakteriyel", "Alerjik", "Tümünde"],
    answerIndex: 1,
    explanation: "Antibiyotikler bakterilere karşı etkilidir; virüslere karşı etkili değildir.",
  },
  {
    id: "q2",
    question: "İlacın dozunu kendi başına artırmak doğru mudur?",
    options: ["Evet", "Hayır"],
    answerIndex: 1,
    explanation: "Doz değişikliği doktor/eczacı kontrolünde olmalıdır.",
  },
  {
    id: "q3",
    question: "Şiddetli alerji belirtisi hangisi olabilir?",
    options: ["Hafif baş ağrısı", "Nefes darlığı", "Hafif uyku hali", "İştah artışı"],
    answerIndex: 1,
    explanation: "Nefes darlığı gibi belirtiler ciddi alerji belirtisi olabilir.",
  },
  {
    id: "q4",
    question: "İlaçları saklarken en doğru yaklaşım hangisi?",
    options: ["Rastgele yerde", "Saklama koşuluna göre", "Güneş gören yerde"],
    answerIndex: 1,
    explanation: "Ambalajda belirtilen saklama koşullarına uyulmalıdır.",
  },
];
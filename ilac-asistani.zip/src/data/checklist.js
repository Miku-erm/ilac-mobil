export const CHECKLIST = [
  "Ellerimi yıkarım",
  "İlacın son kullanma tarihini ve ambalajını kontrol ederim",
  "Ölçü kaşığı / ölçü enjektörü kullanırım",
  "Saklama koşuluna göre saklarım",
  "Açılma tarihini not ederim",
  "Dozu doktor/eczacı önerisine göre belirlerim",
];
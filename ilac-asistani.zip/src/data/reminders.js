export const REMINDERS_SEED = [
  { id: "r1", title: "08:00 - İlacımı al" },
  { id: "r2", title: "20:00 - İlacımı al" },
];
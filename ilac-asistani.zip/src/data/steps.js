export const STEPS = [
  { id: "s1", text: "Ellerimi yıkarım", correctOrder: 1 },
  { id: "s2", text: "Son kullanma tarihi ve ambalajı kontrol ederim", correctOrder: 2 },
  { id: "s3", text: "İlacı sulandırmadan önce çalkalarım", correctOrder: 3 },
  { id: "s4", text: "Önce suyu ekler, sonra çizgiye tamamlarım", correctOrder: 4 },
  { id: "s5", text: "5 dakika bekletirim", correctOrder: 5 },
  { id: "s6", text: "Dozu ölçü enjektörü ile çekerim", correctOrder: 6 },
];
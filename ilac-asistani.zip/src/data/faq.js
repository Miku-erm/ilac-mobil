export const FAQ = [
  { q: "İlaç nedir?", a: "Hastalıkların önlenmesi/tedavisi için kullanılan maddelerdir." },
  { q: "Akıllı ilaç kullanımı nedir?", a: "Doğru ilaç, doğru doz, doğru süre ve doğru kişi prensibidir." },
  { q: "Akılcı olmayan kullanım neye yol açar?", a: "Yan etki artışı, direnç, maliyet ve kaynak israfına yol açabilir." },
  { q: "Antibiyotik nedir?", a: "Bakterilere karşı etkilidir; virüslere karşı etkili değildir." },
];
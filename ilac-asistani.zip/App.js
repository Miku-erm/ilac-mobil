import "react-native-gesture-handler";
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator, DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import { View, Text } from "react-native";

import HomeScreen from "./src/screens/HomeScreen";
import ContentListScreen from "./src/screens/ContentListScreen";
import DetailScreen from "./src/screens/DetailScreen";
import ChecklistScreen from "./src/screens/ChecklistScreen";
import FaqScreen from "./src/screens/FaqScreen";
import StepOrderScreen from "./src/screens/StepOrderScreen";
import QuizScreen from "./src/screens/QuizScreen";
import SearchScreen from "./src/screens/SearchScreen";
import RemindersScreen from "./src/screens/RemindersScreen";
import ProfileScreen from "./src/screens/ProfileScreen";
import AboutScreen from "./src/screens/AboutScreen";

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

function HeaderStyle() {
  return {
    headerStyle: { backgroundColor: "#1565C0" },
    headerTintColor: "#fff",
    headerTitleStyle: { fontWeight: "900" },
  };
}

function HomeStack() {
  return (
    <Stack.Navigator screenOptions={HeaderStyle()}>
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: "Akıllı İlaç Uygulama Asistanı" }} />
      <Stack.Screen name="ContentList" component={ContentListScreen} options={{ title: "Bilgi Kartları" }} />
      <Stack.Screen name="Detail" component={DetailScreen} options={{ title: "Bilgi" }} />
      <Stack.Screen name="Checklist" component={ChecklistScreen} options={{ title: "Kontrol Listesi" }} />
      <Stack.Screen name="FAQ" component={FaqScreen} options={{ title: "Sorular" }} />
    </Stack.Navigator>
  );
}

function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props}>
      <View style={{ backgroundColor: "#1565C0", padding: 16 }}>
        <Text style={{ color: "white", fontWeight: "900", fontSize: 16 }}>kubra</Text>
        <Text style={{ color: "white", opacity: 0.9, marginTop: 4 }}>kubra@example.com</Text>
      </View>

      <DrawerItem label="Akıllı İlaç Uygulama Asistanı" onPress={() => props.navigation.navigate("HomeStack")} />
      <DrawerItem label="Arama" onPress={() => props.navigation.navigate("Arama")} />
      <DrawerItem label="Sorular" onPress={() => props.navigation.navigate("Sorular")} />
      <DrawerItem label="Sıralama Soruları" onPress={() => props.navigation.navigate("Siralama")} />
      <DrawerItem label="Profil" onPress={() => props.navigation.navigate("Profil")} />
      <DrawerItem label="Hakkında" onPress={() => props.navigation.navigate("Hakkinda")} />
      <DrawerItem label="Çıkış yap" onPress={() => props.navigation.navigate("HomeStack")} />
    </DrawerContentScrollView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        screenOptions={HeaderStyle()}
        drawerContent={(props) => <CustomDrawerContent {...props} />}
      >
        <Drawer.Screen name="HomeStack" component={HomeStack} options={{ title: "Akıllı İlaç Uygulama Asistanı" }} />
        <Drawer.Screen name="Arama" component={SearchScreen} />
        <Drawer.Screen name="Sorular" component={FaqScreen} />
        <Drawer.Screen name="Siralama" component={StepOrderScreen} options={{ title: "Sıralama Soruları" }} />
        <Drawer.Screen name="Quiz" component={QuizScreen} options={{ title: "Sorular" }} />
        <Drawer.Screen name="Hatirlatıcı" component={RemindersScreen} options={{ title: "Hatırlatıcı" }} />
        <Drawer.Screen name="Profil" component={ProfileScreen} options={{ title: "Profil" }} />
        <Drawer.Screen name="Hakkinda" component={AboutScreen} options={{ title: "Hakkında" }} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}